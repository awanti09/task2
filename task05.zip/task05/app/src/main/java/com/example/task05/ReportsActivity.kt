package com.example.task05

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class ReportsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_reports)
    }
}